// React에서 NodeJs /post 경로로 Post요청

// =========================================================================== //

// [방법 1] : post, user 테이블 만들어서 join 하기
// post 테이블 컬럼 : 기본키, 제목, 작성자id(user 테이블 참조 외래키), 등록일자, 
//                 cor, lr_Y, rf_Y, 설명
// user 테이블 컬럼 : 기본키, 이메일(유니크 키), 작성자명, 프로필사진

// =========================================================================== //

// [방법 2] : post 테이블에 전부 때려넣기
// post 테이블 컬럼 : 기본키, 제목, 작성자명, 이메일, 프로필사진, 등록일자, 
//                 cor, lr_Y, rf_Y, 설명

// =========================================================================== //

// [ cor, lr_Y, rf_Y, 설명 ] 4개의 컬럼의 타입은 txt
// * txt타입은 char나 varchar가 아님(var, char는 글자 수 제한이 짧음) *
// lr_Y, rf_Y 대소문자 구분

const router = require('express').Router();

// POST 요청을 처리하는 엔드포인트
router.post('/', (req, res) => {
    const data = req.body;
    
    const title = data.title;

    const name = data.name; // 유저명
    const email = data.email;
    const picture = data.picture; // 프로필사진

    const cor = data.cor;
    const lr_Y = data.lr_Y
    const rf_Y = data.rf_Y

    const explain = data.gpt; // 설명

    // 방법 1과 2중에 선택 후 데이터베이스에 자료 insert하는 소스 작성
    
});

module.exports = router;